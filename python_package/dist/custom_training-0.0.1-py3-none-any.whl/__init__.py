from .custom_training import CustomTraining

__version__ = "1.0.0"
__author__ = "Akash Nath, Abhinaba Biswas"